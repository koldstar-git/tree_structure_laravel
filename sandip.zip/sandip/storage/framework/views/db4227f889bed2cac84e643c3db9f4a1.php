<html lang="en">
<head>
    <title>NadSoft PHP Tasks</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <style>
        .row {
            margin-right: 22px;
            margin-left: 22px;
        }
    </style>
</head>
<body>

<div class="container">
    <?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php
        // echo "<pre>";
        // print_r($parent);
        // die;

    ?>
        <ul id="parent-<?php echo e($parent->id); ?>">
            <li>
                <?php echo e($parent->name); ?>

                <?php if($parent->children->count() > 0): ?>
                    <?php
                        appentChild($parent->children);
                    ?>
                <?php endif; ?>
            </li>
        </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php
    function appentChild($children)
        {
            echo '<ul>';
            foreach ($children as $child)
            {
                echo '<li>' . $child->name;
                if ($child->children->count() > 0)
                    {
                        appentChild($child->children);
                    }
                echo '</li>';
            }
            echo '</ul>';
        }
    ?>

    <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#memberModal">Add Member</button>
    <div class="modal fade" id="memberModal" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add Member</h4>
                </div>
                <div class="modal-body">
                    <form id="addmemberForm" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <div class="row m-4 p-4">
                                <label for="nameInput" class="form-label">Parent </label>
                                <select class="form-control" id="parent_id" name="parent_id">
                                    <option value="">Select Parent Name</option>
                                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($member->id); ?>"><?php echo e($member->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3">
                            <div class="row m-4">
                                <label for="nameInput" class="form-label">Name </label>
                                <input type="text" class="form-control" name="name" id="name" placeholder="Member Name" required>
                            </div>
                        </div>
                        <div class="m-3">
                            <div class="row m-4">
                                <div style="text-align: end;">
                                    <button type="button" class="btn btn-secondary popup" data-dismiss="modal" aria-label="Close">Cancel</button>
                                    <button type="submit" class="btn btn-primary popup1">Save Changes</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
    $('#addmemberForm').submit(function(event) {
        event.preventDefault();

        var formData = $(this).serialize();

        $.ajax({
            method: 'post',
            url: '<?php echo e(route('member.store')); ?>',
            data: formData,
            success: function(response) {
                // console.log(response);
                $('#memberModal').modal('hide');
                alert(response.message);

                // console.log("newMember");
                // console.log(response.member);
                // console.log(newMember.parent_id);

                var newMember = response.member;
                // console.log(newMember.parent_id);
                var parentId = newMember.parent_id;
                var parentElement = $('#parent-'+ parentId +' > ul');

                var updatedChild = '<li>' + newMember.name + '</li>';

                parentElement.append(updatedChild);

                location.reload();
            },
            error: function(error) {

            }
        });
    });
});

</script>

</body>
</html>
<?php /**PATH C:\xampp-8.1\htdocs\sandip\resources\views/index.blade.php ENDPATH**/ ?>