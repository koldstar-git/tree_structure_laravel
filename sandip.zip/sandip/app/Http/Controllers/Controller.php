<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
// use Request;
use Illuminate\Http\Request;
use App\Models\Member;

class Controller extends BaseController
{
    use AuthorizesRequests, ValidatesRequests;

    public function index()
    {
        $parents = Member::where('parent_id',0)->get();
        $members = Member :: all();

        return view('index',compact('parents','members'));
    }

    public function store(Request $request)
    {
        //  echo "<pre>";
        // print_r($request->parent_id);
        // die;
        $existing_members = Member :: all();
        $member = new Member;


        if (empty($request->parent_id) && $existing_members->isEmpty())
        {
            $member->parent_id = 0;
            $member->name = $request->name;
            $member->save();
            return response()->json(['message' => 'Member Add Successfully', 'member' => $member]);
        }
        else if (empty($request->parent_id))
        {
            return response()->json(['message' => 'Parent ID is required ']);
        }
        else
        {
            $member->name = $request->name;
            $member->parent_id = $request->parent_id;
            $member->save();
            return response()->json(['message' => 'Member Add Successfully', 'member' => $member]);
        }


    }
}
