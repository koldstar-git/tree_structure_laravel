<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Member extends Model
{
    use HasFactory;

    protected $table = 'members';

    public function getMember()
    {
        // Assuming you have a "users" table with "id" and "name" columns
        $member = Member::find($this->parent_id);

        if ($member) {
            return $member->name;
        }

        return 'Unknown';
    }

    public function children()
    {
        return $this->hasMany(Member::class, 'parent_id', 'id');
    }


}
