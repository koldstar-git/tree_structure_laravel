-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2023 at 10:37 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(10) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `parent_id` int(10) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `members_old`
--

CREATE TABLE `members_old` (
  `id` int(10) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `parent_id` int(10) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `members_old`
--

INSERT INTO `members_old` (`id`, `name`, `parent_id`, `created_at`, `updated_at`) VALUES
(1, 'Sandip', 0, '2023-08-22 17:18:07', '2023-08-22 17:18:07'),
(2, 'Ahirrao', 1, '2023-08-22 17:21:40', '2023-08-22 17:21:40'),
(4, 'Person1', 2, '2023-08-22 17:29:38', '2023-08-22 17:29:38'),
(5, 'Person11', 2, '2023-08-22 17:30:02', '2023-08-22 17:30:02'),
(6, 'Person2', 4, '2023-08-22 17:30:19', '2023-08-22 17:30:19'),
(7, 'Parent22', 5, '2023-08-22 18:27:42', '2023-08-22 18:27:42'),
(8, 'Second', 1, '2023-08-22 18:29:18', '2023-08-22 18:29:18'),
(9, 'Third', 1, '2023-08-22 18:38:21', '2023-08-22 18:38:21'),
(10, 'AA', 4, '2023-08-22 18:39:46', '2023-08-22 18:39:46'),
(11, 'Try User', 5, '2023-08-22 18:40:33', '2023-08-22 18:40:33'),
(12, 'BB', 5, '2023-08-22 18:41:21', '2023-08-22 18:41:21'),
(13, 'XX', 4, '2023-08-22 18:43:22', '2023-08-22 18:43:22'),
(14, 'ZZ', 4, '2023-08-22 18:44:08', '2023-08-22 18:44:08'),
(15, 'AAA', 10, '2023-08-22 18:45:08', '2023-08-22 18:45:08'),
(16, 'QQQ', 7, '2023-08-22 18:45:54', '2023-08-22 18:45:54'),
(17, 'Four', 1, '2023-08-22 18:49:38', '2023-08-22 18:49:38'),
(18, 'Five', 1, '2023-08-22 18:50:53', '2023-08-22 18:50:53'),
(19, 'Six', 1, '2023-08-22 18:52:56', '2023-08-22 18:52:56'),
(20, 'Seven', 1, '2023-08-22 18:54:27', '2023-08-22 18:54:27'),
(21, 'Eight', 1, '2023-08-22 18:55:20', '2023-08-22 18:55:20'),
(22, 'Nine', 1, '2023-08-22 18:57:27', '2023-08-22 18:57:27'),
(23, 'Ten', 1, '2023-08-22 18:58:58', '2023-08-22 18:58:58'),
(24, 'Eeleven', 1, '2023-08-22 19:01:26', '2023-08-22 19:01:26'),
(25, '12', 1, '2023-08-22 19:02:18', '2023-08-22 19:02:18'),
(26, 'Thirtine', 1, '2023-08-22 19:03:07', '2023-08-22 19:03:07'),
(27, 'Try User', 8, '2023-08-22 19:03:47', '2023-08-22 19:03:47'),
(28, 'AAAA', 10, '2023-08-22 19:05:55', '2023-08-22 19:05:55'),
(29, 'PPPPPP', 16, '2023-08-22 19:08:40', '2023-08-22 19:08:40'),
(30, 'MMMMMMM', 29, '2023-08-22 19:09:03', '2023-08-22 19:09:03'),
(31, 'RRRRRRR', 30, '2023-08-22 19:12:29', '2023-08-22 19:12:29'),
(32, 'QQQQ', 9, '2023-08-22 19:14:29', '2023-08-22 19:14:29'),
(33, 'Tested', 24, '2023-08-22 19:22:45', '2023-08-22 19:22:45'),
(34, 'Tested1', 24, '2023-08-22 19:22:55', '2023-08-22 19:22:55'),
(35, 'YYYYYYYYYYYY', 31, '2023-08-22 19:26:16', '2023-08-22 19:26:16'),
(36, 'QPDDD', 1, '2023-08-22 19:26:53', '2023-08-22 19:26:53'),
(37, 'ppppppppppppppp', 36, '2023-08-22 19:28:16', '2023-08-22 19:28:16'),
(38, 'BBBBBBBBBBBB', 37, '2023-08-22 19:30:50', '2023-08-22 19:30:50'),
(39, 'qqqqqqqqqqqqqqqqqqqqqqq', 38, '2023-08-22 19:31:41', '2023-08-22 19:31:41'),
(40, 'qqqqq', 6, '2023-08-22 19:32:36', '2023-08-22 19:32:36'),
(41, 'eeeeeeeee', 20, '2023-08-22 19:33:39', '2023-08-22 19:33:39'),
(42, 'AA', 39, '2023-08-22 19:34:14', '2023-08-22 19:34:14'),
(43, 'qq', 4, '2023-08-22 19:34:48', '2023-08-22 19:34:48'),
(44, 'ZZ', 42, '2023-08-22 19:35:35', '2023-08-22 19:35:35'),
(45, 'qwert', 2, '2023-08-22 19:36:01', '2023-08-22 19:36:01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members_old`
--
ALTER TABLE `members_old`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `members_old`
--
ALTER TABLE `members_old`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
