<html lang="en">
<head>
    <title>NadSoft PHP Tasks</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <style>
        .row {
            margin-right: 22px;
            margin-left: 22px;
        }
    </style>
</head>
<body>

<div class="container">
    @foreach ($parents as $parent)

    <?php
        // echo "<pre>";
        // print_r($parent);
        // die;

    ?>
        <ul id="parent-{{ $parent->id }}">
            <li>
                {{ $parent->name }}
                @if ($parent->children->count() > 0)
                    @php
                        appentChild($parent->children);
                    @endphp
                @endif
            </li>
        </ul>
    @endforeach

    @php
    function appentChild($children)
        {
            echo '<ul>';
            foreach ($children as $child)
            {
                echo '<li>' . $child->name;
                if ($child->children->count() > 0)
                    {
                        appentChild($child->children);
                    }
                echo '</li>';
            }
            echo '</ul>';
        }
    @endphp

    <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#memberModal">Add Member</button>
    <div class="modal fade" id="memberModal" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add Member</h4>
                </div>
                <div class="modal-body">
                    <form id="addmemberForm" method="post">
                        @csrf
                        <div class="mb-3">
                            <div class="row m-4 p-4">
                                <label for="nameInput" class="form-label">Parent </label>
                                <select class="form-control" id="parent_id" name="parent_id">
                                    <option value="">Select Parent Name</option>
                                    @foreach($members as $member)
                                    <option value="{{ $member->id }}">{{ $member->name }}</option>
                                @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="mb-3">
                            <div class="row m-4">
                                <label for="nameInput" class="form-label">Name </label>
                                <input type="text" class="form-control" name="name" id="name" placeholder="Member Name" required>
                            </div>
                        </div>
                        <div class="m-3">
                            <div class="row m-4">
                                <div style="text-align: end;">
                                    <button type="button" class="btn btn-secondary popup" data-dismiss="modal" aria-label="Close">Cancel</button>
                                    <button type="submit" class="btn btn-primary popup1">Save Changes</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
    $('#addmemberForm').submit(function(event) {
        event.preventDefault();

        var formData = $(this).serialize();

        $.ajax({
            method: 'post',
            url: '{{ route('member.store') }}',
            data: formData,
            success: function(response) {
                // console.log(response);
                $('#memberModal').modal('hide');
                alert(response.message);

                // console.log("newMember");
                // console.log(response.member);
                // console.log(newMember.parent_id);

                var newMember = response.member;
                // console.log(newMember.parent_id);
                var parentId = newMember.parent_id;
                var parentElement = $('#parent-'+ parentId +' > ul');

                var updatedChild = '<li>' + newMember.name + '</li>';

                parentElement.append(updatedChild);

                location.reload();
            },
            error: function(error) {

            }
        });
    });
});

</script>

</body>
</html>
